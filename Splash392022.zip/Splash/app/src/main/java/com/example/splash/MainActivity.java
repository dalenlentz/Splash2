package com.example.splash;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
//variables to be used in input validation
    EditText clientcode;
    EditText email;
    EditText password;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//instantiate variables
        email = findViewById(R.id.editTextTextEmailAddress2);
        button = findViewById(R.id.button);
        password = findViewById(R.id.editTextTextPassword2);
        clientcode = findViewById(R.id.editTextTextPersonName3);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateEmailAddress(email);
                validatePassword(password);

            }
        });
    }
//this function validates email address
    private boolean validateEmailAddress(EditText email) {
        String emailInput = email.getText() .toString();

        if(!emailInput.isEmpty()  && Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()){
            //comment out this  line when live
            //Toast.makeText(this, "Email Validated Successfully!", Toast.LENGTH_SHORT).show();
            //return true;
        }else
            Toast.makeText(this, "Invalid Email Address", Toast.LENGTH_SHORT).show();
            return false;
    }
    /*this function validates password using regular expression
    8-20 characters, 1 lower case, 1 upper case, 1 special character

     */
    private boolean validatePassword(EditText password) {
        String passwordInput = password.getText() .toString();
        String regex = "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(passwordInput);

        //if(!passwordInput.isEmpty()  && m.matches()) {
            //comment out this line when live
            //Toast.makeText(this, "Password Validated Successfully!", Toast.LENGTH_SHORT).show();
           // return true;

            ApplicationInfo ai = null;
            try {
                ai = getBaseContext().getPackageManager().getApplicationInfo(getBaseContext().getPackageName(), PackageManager.GET_META_DATA);
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            String Mode = (String) ai.metaData.get("Mode");
            String DevURL = (String) ai.metaData.get("DevURL");
            String ProdURL = (String) ai.metaData.get("ProdURL");
            String EZyTrackVersion = (String) ai.metaData.get("EZyTrackVersion");

            String ezyTrackURL = "";

        if(Mode.equals("Dev")){
            ezyTrackURL = DevURL + "/" + EZyTrackVersion + "/" + clientcode.getText() .toString() + "/sessions";


        }else
            ezyTrackURL = ProdURL;
        return false;
    }

       // }else
           // Toast.makeText(this, "Invalid Password", Toast.LENGTH_SHORT).show();
        //return false;
   // }
}